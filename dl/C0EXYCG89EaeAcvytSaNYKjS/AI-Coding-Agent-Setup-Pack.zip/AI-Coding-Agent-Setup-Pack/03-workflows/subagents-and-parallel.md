# Workflow: Subagents and parallel agents

## Why
Every file the main agent reads fills its context. Long contexts get slower, costlier and sloppier. Subagents do the reading and return only conclusions.

## Good subagent jobs
- **Search/survey:** "Find every place we call the payments API. Return file:line and a one-line description. Do not edit."
- **Independent review:** "Review this diff for security issues only."
- **Research:** "Read the docs for library X v5 migration and list breaking changes that affect our usage in src/."
- **Test triage:** "Run the test suite, group failures by root cause, return the groups."

## Bad subagent jobs
- Tightly coupled edits across the same files (they'll conflict).
- Anything needing the full conversation history.

## Writing a subagent brief
```
Task: <<one sentence>>
Scope: <<paths it may read>>; it may NOT edit files.
Return format: <<e.g. markdown table: file | line | finding>>, max <<20>> rows.
Stop condition: <<e.g. after checking src/ and lib/>>.
```

## Parallel agents on separate tasks
1. One git worktree + branch per agent (see safe-git-habits.md).
2. Tasks must not overlap in files. Split by module, not by layer.
3. Each agent gets the same AGENTS.md and its own NOTES.md.
4. Merge one at a time; rerun tests after each merge.

Rule of thumb: 2–3 parallel agents is the limit most people can review well. Beyond that, review becomes the bottleneck.
