# Workflow: Safe git habits with agents

Agents work fast; git is your undo button. Set it up so every mistake is cheap.

## Before the agent starts
- Clean working tree: `git status` shows nothing. Commit or stash your own work first.
- New branch per task: `git switch -c agent/<short-task-name>`.
- For parallel agents use worktrees: `git worktree add ../repo-task-b -b agent/task-b`.

## While it works
- Ask for a commit after each verified step, with a message describing *why*.
- Review with `git diff --stat` first (scope), then `git diff` (content).
- If it went sideways: `git restore .` (uncommitted) or `git reset --hard <last-good-commit>` on the agent branch only.

## Rules to put in AGENTS.md
```
- Never run: git push --force, git reset --hard on shared branches, git clean -fdx, git rebase on pushed branches, or anything that rewrites history, without asking.
- Never commit to main directly. Never push unless asked.
- Never use --no-verify to skip hooks.
- Stage files explicitly (git add <paths>), not git add -A, to avoid committing stray files.
```

## Before merge
- Squash noisy WIP commits if your team prefers, then rerun the full test suite.
- Check for accidental files: `git diff --name-only main...HEAD` — look for `.env`, large binaries, lockfile churn, generated files.
- Secret scan: `git diff main...HEAD | grep -iE "(api[_-]?key|secret|token|password)\s*[:=]"`.

## Tool permissions
Allow-list safe commands (tests, lint, git status/diff/log) for auto-approval; keep `git push`, package installs, `rm -rf` and network calls on manual approval.
