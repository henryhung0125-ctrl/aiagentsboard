# Workflow: Plan, then execute

The single biggest quality lever. Agents that edit immediately make confident, wide, wrong changes; agents that plan first make reviewable ones.

## The loop
1. **Explore (read-only).** Ask the agent to read relevant files and explain current behavior. Use plan/ask mode where your tool has it.
2. **Plan.** Use `02-prompts/01-plan.md`. Plans list files, steps and a verification per step.
3. **Review the plan (2 minutes, worth hours).** Look for: touching files it shouldn't, missing migration/test steps, vague steps ("update logic").
4. **Execute in slices.** One step at a time, verify, commit. Small commits make rollback cheap.
5. **Verify independently.** Run the Definition of Done yourself or in CI. Don't accept "tests should pass".
6. **Review.** `02-prompts/05-code-review.md` in a fresh context.

## When to skip planning
Typos, one-line fixes, renaming a local variable, adding a log line. If you can state the diff in one sentence, just ask for it.

## Signals the plan is bad
- No verification steps.
- "Refactor X" with no list of what moves where.
- New dependencies you didn't ask for.
- Touches auth, payments, migrations or deploy config without calling out risk.

## Writing good goals
Bad: "improve the search". Good: "search results for 'tshirt' must include 't-shirt' products; add a test with these 3 product names".
