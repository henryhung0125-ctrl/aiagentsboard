# Workflow: Context hygiene

- **Start fresh per task.** A new task in an old, long session inherits stale assumptions.
- **Point, don't paste.** Give paths (`see lib/db/invoices.ts`) rather than pasting whole files; paste only error output and short snippets.
- **Keep AGENTS.md short (<150 lines).** Move rarely needed detail to `docs/` and link it: "For the release process see docs/release.md".
- **Use NOTES.md for continuity** (`02-prompts/06-handoff.md`) instead of relying on memory across sessions.
- **Correct once, codify forever.** When you correct the agent twice about the same thing, add it to AGENTS.md "Do not" or "Gotchas".
- **Prune.** Review AGENTS.md monthly; delete rules the agent already follows by default and anything outdated.
