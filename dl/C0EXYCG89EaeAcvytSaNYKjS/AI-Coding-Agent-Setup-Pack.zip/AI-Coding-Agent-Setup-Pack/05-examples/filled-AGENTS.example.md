# AGENTS.md — Shoplet (example, filled in)

## Project in one paragraph
Shoplet is a Next.js storefront for small print shops. Customers browse products, upload artwork and pay with Stripe. Checkout and artwork upload must never break.

## Commands
- Install: `pnpm install --frozen-lockfile`
- Type-check: `pnpm typecheck` · Lint: `pnpm lint` · Test one: `pnpm test -- path` · All: `pnpm test`
- E2E: `pnpm e2e` (needs `pnpm dev` running and `STRIPE_TEST_KEY` set)
Definition of done: typecheck + lint + test pass.

## Do not
- Do not touch `app/api/webhooks/stripe/` without asking (idempotency is subtle).
- Do not change prices in `lib/catalog.ts`; they sync from the admin.
- Do not add deps, edit the lockfile, or reformat untouched files.

## Gotchas
- Uploaded artwork goes to S3 via presigned URLs; never proxy file bytes through our API (Vercel 4.5 MB limit).
- `formatMoney` expects integer cents, not dollars.
- E2E tests share one seeded test user; don't delete it in teardown.
