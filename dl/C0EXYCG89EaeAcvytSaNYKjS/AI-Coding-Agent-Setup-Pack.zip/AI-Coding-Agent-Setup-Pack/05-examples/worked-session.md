# Worked example: adding CSV export, end to end

A condensed, realistic session using this pack. Stack: Next.js web app (web-app templates).

## 1. Plan prompt (from 02-prompts/01-plan.md)
> Goal: Users can download their invoices as CSV from /billing. Context: app/billing/page.tsx, lib/db/invoices.ts. Constraints: no new deps; must handle 10k+ rows. Do NOT edit files yet...

## 2. Agent's plan (what a good one looks like)
1. `lib/csv.ts` — add `toCsvRow(values: string[])` with RFC 4180 quoting. Verify: unit tests for commas, quotes, newlines, unicode.
2. `app/api/invoices/export/route.ts` — GET handler; auth check; streams rows via `ReadableStream` using a cursor from `lib/db/invoices.ts#iterateInvoices`. Verify: route test with 3 invoices; 401 when logged out.
3. `lib/db/invoices.ts` — add `iterateInvoices(userId, batchSize=500)`. Verify: test that it yields all rows across batch boundaries (1001 rows).
4. `app/billing/page.tsx` — "Export CSV" link to the route. Verify: e2e clicks link, file downloads, header row correct.
Risks: memory on large accounts (handled by streaming); CSV injection (prefix cells starting with = + - @ with a single quote).
Estimated diff: ~180 lines incl. tests.

## 3. Human review of the plan
> Approved. Also set `Content-Disposition` filename to `invoices-YYYY-MM-DD.csv`. Do step 1 only, then show test output.

## 4. Execution (per step)
Agent implements step 1, runs `pnpm test -- lib/csv.test.ts` → 6 passed. Commits `feat(csv): add RFC4180 row encoder with injection guard`. Continues steps 2–4 the same way.

## 5. Fresh-context review (02-prompts/05-code-review.md)
| severity | file:line | issue | fix |
|---|---|---|---|
| should-fix | route.ts:22 | Missing `Cache-Control: no-store` on a per-user file | add header |
| nit | csv.ts:8 | regex recompiled per call | hoist constant |

## 6. Merge
Pre-merge checklist done; CI green; manual download of a 12k-row account took 1.4 s.

**What made this work:** precise goal, constraints up front, verification per step, small commits, and an independent review.
