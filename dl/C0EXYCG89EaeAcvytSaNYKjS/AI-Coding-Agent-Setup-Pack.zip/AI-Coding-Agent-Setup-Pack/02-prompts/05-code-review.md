# Prompt: Code review (of your own branch or an agent's diff)

```
Review the changes in <<`git diff main...HEAD` / PR #>> as a strict senior reviewer.

Check, in this order:
1. Correctness: logic errors, off-by-one, null/undefined, async/race issues, error handling.
2. Security: input validation, authz checks, injection, secrets, unsafe deserialization, SSRF.
3. Data: migrations reversible? backwards compatible? any data loss path?
4. Tests: do they cover the new behavior and edge cases? any test weakened or deleted?
5. Scope creep: changes unrelated to the stated goal (<<goal>>).
6. Readability and consistency with AGENTS.md conventions.

Output a table: severity (blocker / should-fix / nit) | file:line | issue | suggested fix.
Only report real issues — no praise, no generic advice. If there are no blockers, say so explicitly.
Do not edit files.
```

Tip: run this in a fresh session (or a subagent) so the reviewer is not biased by the context that produced the code.
