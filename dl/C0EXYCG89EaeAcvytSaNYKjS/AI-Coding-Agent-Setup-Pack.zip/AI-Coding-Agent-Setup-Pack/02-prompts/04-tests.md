# Prompt: Write meaningful tests

```
Write tests for <<file/function/endpoint>>.

First, list the behaviors worth testing as a table: behavior | input | expected | why it matters. Include:
- the main happy path
- boundaries (empty, one, many, max, zero, negative, unicode, timezones)
- error paths (invalid input, dependency failure, timeouts)
- any bug fixed recently in this code (check git log)

Then implement them following the existing test style in <<path to a good existing test>>.
Rules:
- Test behavior through the public interface, not private helpers.
- No network, no real clock, no sleeps. Mock at the boundary (HTTP client, DB adapter).
- Each test name states behavior + condition.
- Do not change production code. If something is untestable, tell me why and suggest the smallest seam.
- Run the tests and show output. Then break the code briefly (e.g. flip a condition) to confirm at least one test fails, and revert.
```
