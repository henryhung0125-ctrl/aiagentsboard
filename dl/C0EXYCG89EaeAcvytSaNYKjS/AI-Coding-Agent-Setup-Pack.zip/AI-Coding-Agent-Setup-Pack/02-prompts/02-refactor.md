# Prompt: Behavior-preserving refactor

```
Refactor <<target: file/function/module>> to <<goal: e.g. split the 600-line OrderService into pricing, tax and persistence modules>>.

Rules:
- Behavior must not change. No new features, no bug fixes mixed in (list bugs you find separately).
- Public interfaces stay the same unless I approve otherwise: <<list exports/endpoints that must not change>>.
- Before changing anything, check test coverage of the target. If coverage is thin, first add characterization tests that pin current behavior (including weird edge cases), run them, and show they pass.
- Then refactor in small steps; run the tests after each step.
- Do not rename things outside the target scope. Do not reformat unrelated code.

Deliver: summary of the new structure, a list of moved/renamed symbols, test results before and after.
```

Tip: for big refactors, ask for the plan with `01-plan.md` first and do one module per PR.
