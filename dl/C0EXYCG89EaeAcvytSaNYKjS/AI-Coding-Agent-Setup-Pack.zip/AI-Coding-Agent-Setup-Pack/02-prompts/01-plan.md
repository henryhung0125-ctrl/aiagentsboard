# Prompt: Plan before you code

Use for any change touching 3+ files, any new feature, or anything you can't describe in one sentence.

```
Goal: <<one sentence: the user-visible outcome>>
Context: <<links/paths: issue, relevant files, error output>>
Constraints: <<e.g. no new deps, keep API stable, must ship behind flag X>>

Do NOT edit any files yet. First:
1. Read the relevant code and summarize how it works today (max 10 lines, with file paths).
2. List any assumptions or open questions. If a question blocks the plan, ask it and stop.
3. Propose a plan as numbered steps. For each step: files touched, what changes, how we verify it.
4. List risks (data, auth, performance, backwards compatibility) and how the plan handles each.
5. Estimate the diff size. If it's over ~300 lines, propose how to split it into separate PRs.

Wait for my approval before implementing.
```

## Follow-up after approval
```
Approved with these changes: <<edits>>. Implement step 1 only, run the verification for that step, show me the result, then continue step by step. Stop if any step's verification fails.
```

## Example (filled)
```
Goal: Users can export their invoices as CSV from /billing.
Context: app/billing/page.tsx, lib/db/invoices.ts, issue #412.
Constraints: no new dependencies; must stream for accounts with 10k+ invoices.
Do NOT edit any files yet. First: ...
```
