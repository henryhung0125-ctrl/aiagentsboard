# Prompt: Debug from evidence

```
Bug: <<what happens>> vs expected: <<what should happen>>.
Repro: <<exact steps or command>>
Evidence: <<full error / stack trace / log lines / failing test output — paste it, don't paraphrase>>
Recent changes: <<commit range or "unknown">>

Process:
1. Reproduce the bug first and show me the output. If you can't reproduce it, stop and tell me what you tried.
2. List 2–4 hypotheses ranked by likelihood, each with the evidence for/against.
3. Test the top hypothesis with the cheapest check (a log line, a REPL call, a focused test). No speculative fixes.
4. Once the root cause is confirmed, write a failing regression test, then the minimal fix.
5. Show the test going red → green and run the related suite.

Do not: wrap it in try/except to hide it, add retries/sleeps as a fix, or change unrelated code.
Report: root cause in 2–3 sentences, the fix, and whether other code paths could have the same bug.
```
