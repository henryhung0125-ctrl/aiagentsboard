# Prompt: Handoff / end-of-session note

```
Before we stop, write NOTES.md (overwrite) with:
- Goal (1 line)
- Done (bullets, with file paths and commit hashes)
- Verified (commands run + results)
- Not done / next steps (ordered)
- Open questions and decisions made (with reasons)
- Gotchas discovered (things the next session must know)
Keep it under 40 lines.
```
Start the next session with: `Read NOTES.md and AGENTS.md, then continue from "Next steps" item 1. Confirm your understanding in 3 lines before editing.`
