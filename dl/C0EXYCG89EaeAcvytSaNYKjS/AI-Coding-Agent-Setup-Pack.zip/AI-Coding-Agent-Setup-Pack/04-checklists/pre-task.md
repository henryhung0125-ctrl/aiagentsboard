# Checklist: Before each task (1 minute)

- [ ] Clean tree, new branch (or worktree)
- [ ] Goal written as an observable outcome + how to verify it
- [ ] Relevant paths / errors / issue link ready
- [ ] Constraints stated (no new deps, API stable, etc.)
- [ ] Planning needed? (3+ files or unclear → yes, use 01-plan.md)
- [ ] Fresh session (or NOTES.md loaded)
