# Checklist: Make a repo agent-ready (one time, ~30 min)

- [ ] AGENTS.md at repo root with exact install/test/lint/type-check/build commands
- [ ] Every command in AGENTS.md actually runs on a clean checkout (try it!)
- [ ] A single-test command exists and is documented (fast feedback loop)
- [ ] CLAUDE.md imports AGENTS.md (`@AGENTS.md`) instead of duplicating it
- [ ] `.cursor/rules/00-core.mdc` (alwaysApply) + 1–3 glob-scoped rules
- [ ] "Do not" section covers: deps, lockfile, migrations, secrets, deleting tests, force-push
- [ ] `.env.example` lists all env vars; real `.env` is gitignored
- [ ] Pre-commit hooks / CI run lint + tests (agents can't "forget" them)
- [ ] Safe commands allow-listed in your agent tool; risky ones require approval
- [ ] Ran one small task end-to-end and fixed whatever the agent misunderstood
