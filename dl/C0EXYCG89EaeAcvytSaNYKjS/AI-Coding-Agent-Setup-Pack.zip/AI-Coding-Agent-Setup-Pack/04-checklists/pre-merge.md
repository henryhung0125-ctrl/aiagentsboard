# Checklist: Before merging agent-written code

- [ ] I read the whole diff (not just the summary)
- [ ] `git diff --stat` shows only expected files; no lockfile/format churn
- [ ] Type-check, lint, full tests pass in CI, not just "locally per the agent"
- [ ] New behavior has tests; no tests deleted, skipped or loosened
- [ ] Ran the feature manually once (UI click-through or CLI call)
- [ ] Error paths handled; no swallowed exceptions
- [ ] No secrets, debug prints, TODOs without issues, commented-out code
- [ ] Security-sensitive areas (auth, payments, uploads, SQL) double-checked
- [ ] Migrations are reversible and backwards compatible
- [ ] Fresh-context review prompt (05-code-review.md) run; blockers resolved
- [ ] Commit messages explain why
