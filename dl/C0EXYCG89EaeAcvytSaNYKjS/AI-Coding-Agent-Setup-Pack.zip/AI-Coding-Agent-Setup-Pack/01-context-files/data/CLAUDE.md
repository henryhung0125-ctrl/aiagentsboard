# CLAUDE.md

@AGENTS.md

## Claude-specific notes
- AGENTS.md above is the source of truth. Do not duplicate rules here; edit AGENTS.md instead.
- Use plan mode for any change touching 3+ files; present the plan and wait.
- For broad searches ("where is X used?"), use a subagent so the main context stays small, and ask it to return file paths + one-line findings only.
- Before ending a turn, run the Definition of Done commands and report results.
- If context gets long, write a short status to `NOTES.md` (goal, done, next, open questions) before compacting.
