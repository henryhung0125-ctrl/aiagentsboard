# AGENTS.md — <<PROJECT NAME>> (Data / analytics: Python, SQL, notebooks)

## Purpose
<<Which questions this repo answers, which datasets it owns, who consumes outputs (dashboards, reports, models).>>

## Commands
- Setup: `uv sync` (or `conda env create -f environment.yml`)
- Run pipeline step: `uv run python -m pipelines.<<step>> --date YYYY-MM-DD`
- Tests: `uv run pytest -q`
- SQL lint: `uv run sqlfluff lint models/`
- dbt (if used): `dbt build --select <<model>>+` — never `dbt run` against prod targets.

## Data rules (most important section)
- Never modify files in `data/raw/`. Raw is immutable; write to `data/interim/` or `data/processed/`.
- Never print or commit PII. Columns <<email, phone, address, user_id>> are sensitive; aggregate or hash them.
- Default to the dev/sample warehouse target. Ask before running anything against prod.
- Any query over <<10 GB>> scanned: estimate cost first and ask.
- Notebooks are for exploration only. Reusable logic moves into `src/` with tests.

## Conventions
- pandas: method chaining, explicit dtypes on read, no `inplace=True`. Use polars where already used.
- Every transform function: input schema → output schema documented in the docstring.
- Validate assumptions with asserts (row counts, uniqueness of keys, null rates) right after joins.
- Joins: state the expected cardinality (1:1, 1:many) and check it.
- Plots: label axes with units; save to `reports/figures/` with a descriptive filename.
- Dates: store UTC; convert only for display.

## Analysis output format
When asked an analytical question, answer with: (1) the direct answer with numbers, (2) the query/code used, (3) caveats (sample size, missing data, definitions), (4) a suggested next check.

## Do not
- Do not drop rows silently; log how many were removed and why.
- Do not fill nulls without stating the strategy.
- Do not change metric definitions in `metrics/` without approval.
- Do not commit data files or notebook outputs with data (`nbstripout` is installed).
