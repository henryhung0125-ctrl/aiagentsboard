# AGENTS.md — <<PROJECT NAME>> (Web app: TypeScript + React/Next.js)

## Project in one paragraph
<<What the app does, who uses it, and the one thing that must never break (e.g. checkout, auth).>>

## Commands (run from repo root)
- Install: `pnpm install --frozen-lockfile`
- Dev server: `pnpm dev` (http://localhost:3000)
- Type-check: `pnpm typecheck`
- Lint: `pnpm lint` (auto-fix: `pnpm lint --fix`)
- Unit tests, single file: `pnpm test -- path/to/file.test.ts`
- Unit tests, all: `pnpm test`
- E2E: `pnpm e2e` (slow; run only when touching routes, auth or forms)
- Build: `pnpm build`

Definition of done for any change: `pnpm typecheck && pnpm lint && pnpm test` pass, plus `pnpm build` if you touched config, routing or env.

## Layout
- `app/` routes (Next.js App Router). Server components by default; add `"use client"` only when you need state/effects.
- `components/` shared UI. `components/ui/` = primitives, do not add business logic there.
- `lib/` pure helpers and API clients. `lib/db/` = data access only.
- `tests/` and `*.test.ts(x)` colocated unit tests. `e2e/` Playwright.

## Conventions
- TypeScript strict. No `any`; use `unknown` + narrowing. No non-null `!` unless commented why.
- Data fetching in server components or route handlers, never in `useEffect` for initial data.
- Validate all external input with zod at the boundary (`lib/schemas/`).
- Styling: <<Tailwind / CSS modules>>. Reuse tokens; no hard-coded colors.
- Naming: components `PascalCase.tsx`, hooks `useThing.ts`, utilities `camelCase.ts`.
- Errors: throw typed errors in `lib/`, convert to HTTP responses only in route handlers.

## Do not
- Do not add dependencies without asking. Prefer the platform and existing deps.
- Do not edit `pnpm-lock.yaml` by hand or run `pnpm update`.
- Do not change public API routes, DB schema or env var names without an explicit instruction.
- Do not reformat files you are not otherwise changing.
- Do not delete or skip failing tests to get green; fix the cause or report it.
- Do not commit secrets; `.env*` files stay local. Use `.env.example` for new keys.

## Working style
- For anything over ~30 lines or touching 3+ files: write a short plan first and wait for approval.
- Keep diffs focused. If you notice unrelated problems, list them at the end instead of fixing them.
- When unsure about intent, ask one precise question rather than guessing.
- Finish with: files changed, commands run and their result, and anything left undone.

## Gotchas
- <<e.g. `NEXT_PUBLIC_*` vars are inlined at build time; changing them needs a rebuild.>>
- <<e.g. Auth middleware lives in `middleware.ts`; matcher excludes `/api/webhooks`.>>
