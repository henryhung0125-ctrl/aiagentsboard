# AGENTS.md — <<PROJECT NAME>> (Python service / library)

## Project in one paragraph
<<What it does, main entry points, who calls it.>>

## Environment and commands
- Python <<3.12>>, managed with `uv` (swap for poetry/pip-tools if that's what you use).
- Setup: `uv sync`
- Run: `uv run python -m <<package>>` or `uv run <<cli-name>> --help`
- Tests, one file: `uv run pytest tests/test_x.py -q`
- Tests, one test: `uv run pytest tests/test_x.py::test_name -q`
- All tests: `uv run pytest -q`
- Lint + format: `uv run ruff check . && uv run ruff format --check .`
- Types: `uv run mypy src`

Definition of done: ruff, mypy and pytest pass. New behavior has a test.

## Layout
- `src/<<package>>/` library code (src layout). `tests/` mirrors it.
- `src/<<package>>/api/` HTTP layer only (FastAPI routers). Business logic goes in `services/`.
- `src/<<package>>/adapters/` I/O: DB, queues, external APIs. Everything else stays pure and testable.

## Conventions
- Type hints on all public functions. Prefer `dataclass(frozen=True)` or pydantic models over dicts.
- No module-level side effects (no network/DB on import).
- Use `logging.getLogger(__name__)`, never `print` in library code.
- Raise specific exceptions; never bare `except:`. Catch `Exception` only at process edges, and log it.
- Time: timezone-aware `datetime` in UTC internally.
- Tests: pytest functions + fixtures, no unittest classes. Use `tmp_path`, `monkeypatch`; no real network (mock at the adapter).

## Do not
- Do not add or upgrade dependencies without asking. Never edit the lockfile by hand.
- Do not change DB migrations that have already been applied; create a new one.
- Do not silence mypy/ruff with ignores unless you explain why in a comment.
- Do not weaken or delete tests to make them pass.
- Do not touch `<<settings/prod.py, deploy/>>`.

## Working style
- Plan first for multi-file changes. Show the plan as a numbered list with files.
- Write or update the test first when fixing a bug: show it failing, then fix.
- End with: summary, files changed, commands run + results, open questions.

## Gotchas
- <<e.g. Tests need `DATABASE_URL` pointing at the docker-compose Postgres: `docker compose up -d db`.>>
