# AI Coding Agent Setup Pack (v1.0)

A practical, opinionated kit for getting reliable work out of AI coding agents such as Claude Code, Cursor and Codex-style CLI agents.

Unofficial. Not affiliated with, endorsed by, or sponsored by Anthropic, OpenAI, Anysphere (Cursor) or any tool vendor. Product names are used only to describe compatibility.

## What's inside

| Folder | What it is | Use it when |
|---|---|---|
| `01-context-files/` | Drop-in `CLAUDE.md`, `AGENTS.md` and `.cursor/rules/*.mdc` for 3 stacks (web app, Python service/library, data/analytics) | Starting or onboarding a repo |
| `02-prompts/` | 6 prompt templates: plan, refactor, debug, tests, code review, handoff | Every task |
| `03-workflows/` | Plan-then-execute, safe git habits, subagents/parallel agents, context hygiene | Building your routine |
| `04-checklists/` | Pre-task, pre-merge and repo-setup checklists | Before you start / before you merge |
| `05-examples/` | A worked, end-to-end session transcript (plan → diff → review) and a filled-in context file | Learning by example |

## 10-minute quick start

1. Pick your stack folder in `01-context-files/` and copy the files into your repo root:
   - `AGENTS.md` is the cross-tool file (read by Codex-style agents, Cursor and many others).
   - `CLAUDE.md` is a thin pointer that imports `AGENTS.md` plus Claude-specific notes, so you maintain one source of truth.
   - `.cursor/rules/*.mdc` are scoped rules for Cursor (always-on core + glob-scoped files).
2. Fill in every `<<PLACEHOLDER>>` (search for `<<`). Delete sections that do not apply. Shorter is better: aim for under 150 lines.
3. Run the `04-checklists/repo-setup.md` checklist once.
4. For your next task, use `02-prompts/01-plan.md`, approve the plan, then execute.

## Design principles (why this pack works)

1. **Commands over prose.** Agents act on exact commands (`pnpm test -- path`) far more reliably than on descriptions ("run the tests").
2. **Verification is part of the task.** Every template ends with a "prove it" step: tests, type-check, lint, or a reproduction.
3. **Small, reviewable diffs.** The prompts cap scope and ask for a plan before edits.
4. **Explicit "do not" lists.** Most agent damage comes from unrequested changes: reformatting, dependency bumps, deleted tests, force-pushes.
5. **One source of truth.** `AGENTS.md` holds the rules; tool-specific files point to it.

## License

Personal and commercial use inside your own projects and team is allowed, including editing and committing the templates to your repos. Please do not resell or republish the pack itself.

Questions or refunds (within 7 days of purchase): sitop@mail.grokbot.com
